<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use App\Repository\PersonneRepository;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Personne;
use App\Form\PersonneType;
class PersonneController extends AbstractController
{
    #[Route('/personne', name: 'app_personne')]
    public function index(): Response
    {
        return $this->render('personne/index.html.twig', [
            'controller_name' => 'PersonneController',
        ]);
    }

    #[Route('/listpersonne', name: 'app_list_personne')]
    public function listAuthors(PersonneRepository $r): Response
    {
        $personnes=$r->findAll();
        return $this->render('personne/list.html.twig', [
            'personnes' => $personnes,
        ]);
    } 

    #[Route('/create', name: 'app_create_personne')]
    public function addAuthor(Request $request, EntityManagerInterface  $entityManager): Response
    {
        $personne=new Personne;
        $form=$this->createform(PersonneType::class, $personne);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $entityManager->persist($personne);
            $entityManager->flush();
        
        return $this->redirectToRoute('app_list_personne');
        }
        return $this->render('Personne/add.html.twig',['form'=>$form->createView(),]);

    }
    #[Route('/personne/{id}/edit', name:'personne_edit')]
    public function edit(Request $request, Personne $personne, EntityManagerInterface $entityManager): Response
    {
    $form = $this->createForm(PersonneType::class, $personne);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $entityManager->flush();

        return $this->redirectToRoute('app_list_personne');
    }

    return $this->render('personne/edit.html.twig', [
        'form' => $form->createView(),
    ]);
}


 #[Route('/personne/{id}/delete', name:'personne_delete')]
 
public function delete(Personne $personne, EntityManagerInterface $entityManager): Response
{
    $entityManager->remove($personne);
    $entityManager->flush();

    return $this->redirectToRoute('app_list_personne');
}

}
