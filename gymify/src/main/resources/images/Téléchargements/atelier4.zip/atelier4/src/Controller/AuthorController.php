<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use App\Repository\AuthorRepository;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Author;
use Symfony\Component\HttpFoundation\Request;
use App\Form\AuthorType;
class AuthorController extends AbstractController
{
   
    #[Route('/author', name: 'app_author')]
    public function index(): Response
    {
        return $this->render('author/index.html.twig', [
            'controller_name' => 'AuthorController',
        ]);
    }

    #[Route('/listauthor', name: 'app_list_author')]
    public function listAuthors(AuthorRepository $r): Response
    {
        $authors=$r->findAll();
        return $this->render('author/list.html.twig', [
            'authors' => $authors,
        ]);
    }
/*
    #[Route('/createauthor', name: 'app_create_author')]
    public function addAuthor(EntityManagerInterface  $entityManager): Response
    {
        $author=new Author;
        $author->setUsername("salah");
        $author->setEmail("mohamed@esprit");
        $entityManager->persist($author);
        $entityManager->flush();

        return new Response("succes");
    }
*/
    #[Route('/createauthor', name: 'app_create_author')]
    public function addAuthor(Request $request, EntityManagerInterface  $entityManager): Response
    {
        $author=new Author;
        $form=$this->createform(AuthorType::class, $author);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $entityManager->persist($author);
            $entityManager->flush();
        
        return $this->redirectToRoute('app_list_author');
        }
        return $this->render('author/add.html.twig',['form'=>$form->createView(),]);

    }

    
    #[Route('/author/{id}/edit', name:'author_edit')]

public function edit(Request $request, Author $author, EntityManagerInterface $entityManager): Response
{
    $form = $this->createForm(AuthorType::class, $author);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $entityManager->flush();

        return $this->redirectToRoute('app_list_author');
    }

    return $this->render('author/edit.html.twig', [
        'form' => $form->createView(),
    ]);
}


 #[Route('/author/{id}/delete', name:'author_delete')]
 
public function delete(Author $author, EntityManagerInterface $entityManager): Response
{
    $entityManager->remove($author);
    $entityManager->flush();

    return $this->redirectToRoute('app_list_author');
}

}

