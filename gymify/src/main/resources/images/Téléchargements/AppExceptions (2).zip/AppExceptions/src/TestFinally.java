import java.io.IOException;

public class TestFinally {

    public static void main(String[] args) {
        try {
            System.out.println("Enter a code: ");
            int x = System.in.read();
            System.out.println("You entered: " + (char) x);
        } catch (IOException e) {
            System.out.println("An error occurred while reading input: " + e.getMessage());
        } finally {

            System.out.println("Thank you, goodbye.");
        }
    }}


