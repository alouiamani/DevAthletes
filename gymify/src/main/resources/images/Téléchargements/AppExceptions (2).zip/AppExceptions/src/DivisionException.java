import java.util.Scanner;

public class DivisionException {
    static int x = 20;
    static int y;

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println(" Enter a number :");
            int y = scanner.nextInt();
            System.out.println("resultat :" + (x / y));}
        catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }

    }
}