<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use App\Repository\ParkRepository;

class ParkController extends AbstractController
{
    #[Route('/park', name: 'app_park')]
    public function index(): Response
    {
        return $this->render('park/index.html.twig', [
            'controller_name' => 'ParkController',
        ]);
    }
    #[Route('/park/list', name: 'app_park_list')] // Corrigé le nom de la route
    public function parkList(ParkRepository $rep): Response
    {
        $parks = $rep->findAll();
        //Appelle la méthode findAll() du repository pour récupérer tous les auteurs de la base de données et les stocker dans la variable $authors.
        return $this->render('park/park.html.twig', [
            'parks' => $parks
        ]);
    }
}
