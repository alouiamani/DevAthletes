<?php

namespace App\Entity;

use App\Repository\ParkRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ParkRepository::class)]
class Park
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 50)]
    private ?string $code = null;

    /**
     * @var Collection<int, Arbre>
     */
    #[ORM\OneToMany(targetEntity: Arbre::class, mappedBy: 'Park')]
    private Collection $arbres;

    public function __construct()
    {
        $this->arbres = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): static
    {
        $this->code = $code;

        return $this;
    }

    /**
     * @return Collection<int, Arbre>
     */
    public function getArbres(): Collection
    {
        return $this->arbres;
    }

    public function addArbre(Arbre $arbre): static
    {
        if (!$this->arbres->contains($arbre)) {
            $this->arbres->add($arbre);
            $arbre->setPark($this);
        }

        return $this;
    }

    public function removeArbre(Arbre $arbre): static
    {
        if ($this->arbres->removeElement($arbre)) {
            // set the owning side to null (unless already changed)
            if ($arbre->getPark() === $this) {
                $arbre->setPark(null);
            }
        }

        return $this;
    }
}
