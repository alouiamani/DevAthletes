<?php

namespace App\Controller;

use App\Entity\Author;
use App\Form\AuthorSearchType;
 // Importer l'entité Author
use App\Form\AuthorType; // Importer le formulaire AuthorType
use App\Repository\AuthorRepository;// interagir avec les données des auteurs dans la base de données.
use Doctrine\ORM\EntityManagerInterface;// gérer les entités dans Doctrine, notamment pour persister et récupérer des données.
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request; // Importer la classe Request
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class AuthorController extends AbstractController
{
    #[Route('/author', name: 'app_author')]
    public function index(): Response
    {
        return $this->render('author/index.html.twig', [
            'controller_name' => 'AuthorController',
        ]);
    }

    #[Route('/authors/list', name: 'app_authors_list')] // Corrigé le nom de la route
    public function authorsl(AuthorRepository $rep): Response
    {
        $authors = $rep->findAll();
        //Appelle la méthode findAll() du repository pour récupérer tous les auteurs de la base de données et les stocker dans la variable $authors.
        return $this->render('author/authors.html.twig', [
            'authors' => $authors
        ]);
    }

    #[Route('/author/add', name: 'app_author_add')]
    public function add(Request $request, EntityManagerInterface $em): Response
    {
        $author = new Author(); // Créer une nouvelle instance de l'entité 
        $form = $this->createForm(AuthorType::class, $author); //Créer un formulaire en utilisant la classe AuthorType, en liant le formulaire à l'instance de l'auteur que vous venez de créer.

        $form->handleRequest($request); // raite la requête. Cela remplit le formulaire avec les données de la requête (s'il y en a) et vérifie s'il a été soumis.

        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($author); // Marque l'entité Author pour persistance, indiquant à Doctrine que cette entité doit être enregistrée dans la base de données.
            $em->flush(); // Envoie toutes les modifications (ici, l'ajout de l'auteur) à la base de données.

            return $this->redirectToRoute('app_authors_list'); // Redirige l'utilisateur vers la liste des auteurs après que l'auteur a été ajouté avec succès.
        }

        return $this->render('author/add.html.twig', [
            'form' => $form->createView(), // Si le formulaire n'est pas soumis ou n'est pas valide, cette ligne génère la vue add.html.twig pour afficher le formulaire. Elle passe le formulaire à la vue.
        ]);
    }
    #[Route('/author/edit/{id}', name: 'app_author_edit')]
      public function edit(Request $request, Author $author, EntityManagerInterface $em): Response
       {
         $form = $this->createForm(AuthorType::class, $author); // Créer le formulaire avec l'auteur existant

          $form->handleRequest($request); // Gérer la requête

       if ($form->isSubmitted() && $form->isValid()) {
          $em->flush(); // Enregistrer les modifications dans la base de données

          return $this->redirectToRoute('app_authors_list'); // Rediriger après succès
    }

    return $this->render('author/edit.html.twig', [
        'form' => $form->createView(), // Passer le formulaire à la vue
        'author' => $author // Passer l'auteur pour l'affichage si nécessaire
    ]);
     }
     #[Route('/author/delete/{id}', name: 'app_author_delete')]
public function delete(Author $author, EntityManagerInterface $em): Response
{
    $em->remove($author); // Supprimer l'auteur
    $em->flush(); // Enregistrer les modifications dans la base de données

    return $this->redirectToRoute('app_authors_list'); // Rediriger après succès
}
#[Route('/author/search', name: 'app_author_search')]
    public function search(Request $request, AuthorRepository $req): Response
{
    $form = $this->createForm(AuthorSearchType::class);
    $form->handleRequest($request);
    $authors = [];

    if ($form->isSubmitted() && $form->isValid()) {
        // Get minBooks and maxBooks from the form
        $minB= $form->get('minB')->getData();
        $maxB = $form->get('maxBs')->getData();

        // Find authors based on the provided range
        $authors = $req->findByBookCountRange($minB, $maxB);
    }

    return $this->render('author/search.html.twig', [
        'form' => $form->createView(),
        'authors' => $authors, // List of filtered authors
    ]);
}

}



