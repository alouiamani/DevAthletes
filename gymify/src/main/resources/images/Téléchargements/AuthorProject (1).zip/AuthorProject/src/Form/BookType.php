<?php

namespace App\Form;

use App\Entity\Author;
use App\Entity\Book;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType; // Ajout de l'import pour ChoiceType
use Symfony\Component\OptionsResolver\OptionsResolver;

class BookType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('title')
            ->add('pulicationDate', null, [
                'widget' => 'single_text',
            ])
            ->add('enabled')
            ->add('published')
            ->add('Author', EntityType::class, [
                'class' => Author::class,
                'choice_label' => 'username',
            ])
            ->add('category', ChoiceType::class, [
              'choices'  => [
                  'Science-Fiction' => 'science_fiction',
                  'Mystery' => 'mystery',
                  'Autobiography' => 'autobiography',
              ],
              'placeholder' => 'Choisissez une catégorie',
          ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Book::class,
        ]);
    }
}
