<?php

namespace App\Controller;
use App\Entity\Arbre;
use App\Form\ArbreType; // Importer le formulaire AuthorType

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;


class ArbreController extends AbstractController
{
    #[Route('/arbre', name: 'app_arbre')]
    public function index(): Response
    {
        return $this->render('arbre/index.html.twig', [
            'controller_name' => 'ArbreController',
        ]);
    }
    #[Route('/arbre/list', name: 'arbre_list')]
    public function list(EntityManagerInterface $em): Response
    {
        $ArbreRepository = $em->getRepository(Arbre::class);

        $arbres = $ArbreRepository->findAll();

        return $this->render('arbre/arbre.html.twig', [
            'arbres' => $arbres,
        ]);
    }
    #[Route('/arbre/edit/{id}', name: 'app_arbre_edit')]
    public function edit(Request $request, Arbre $arbre, EntityManagerInterface $em): Response
     {
       $form = $this->createForm(ArbreType::class, $arbre); // Créer le formulaire avec l'auteur existant

        $form->handleRequest($request); // Gérer la requête

     if ($form->isSubmitted() && $form->isValid()) {
        $em->flush(); // Enregistrer les modifications dans la base de données

        return $this->redirectToRoute('arbre_list'); // Rediriger après succès
  }

  return $this->render('arbre/edit.html.twig', [
      'form' => $form->createView(), // Passer le formulaire à la vue
      'arbre' => $arbre // Passer l'auteur pour l'affichage si nécessaire
  ]);
   }
}
