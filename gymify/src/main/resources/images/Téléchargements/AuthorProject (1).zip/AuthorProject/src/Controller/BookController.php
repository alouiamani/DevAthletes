<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\HttpFoundation\Request; 
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Book;
use App\Form\BookType;
use App\Repository\BookRepository;




class BookController extends AbstractController
{
    #[Route('/book', name: 'app_book')]
    public function index(): Response
    {
        return $this->render('book/index.html.twig', [
            'controller_name' => 'BookController',
        ]);
    }
    #[Route('/book/add', name: 'app_book_add')]
    public function AddBook(Request $request, EntityManagerInterface $em): Response
    {
        $book = new Book(); // Créer une nouvelle instance de l'entité 
        $book ->setPublished(true);
        $form = $this->createForm(BookType::class, $book); //Créer un formulaire en utilisant la classe AuthorType, en liant le formulaire à l'instance de l'auteur que vous venez de créer.

        $form->handleRequest($request); // raite la requête. Cela remplit le formulaire avec les données de la requête (s'il y en a) et vérifie s'il a été soumis.

        if ($form->isSubmitted() && $form->isValid()) {
            $author=$book->getAuthor();// Récupérer l'auteur du livre soumis via le formulaire

            $author->incrementNbBooks();
            $em->persist($author);
            $em->persist($book); // Marque l'entité Author pour persistance, indiquant à Doctrine que cette entité doit être enregistrée dans la base de données.
            $em->flush(); // Envoie toutes les modifications (ici, l'ajout de l'auteur) à la base de données.

            return $this->redirectToRoute('app_book_add'); // Redirige l'utilisateur vers la liste des auteurs après que l'auteur a été ajouté avec succès.
        }

        return $this->render('book/addbook.html.twig', [
            'form' => $form->createView(), // Si le formulaire n'est pas soumis ou n'est pas valide, cette ligne génère la vue add.html.twig pour afficher le formulaire. Elle passe le formulaire à la vue.
        ]);
      
         }
         #[Route('/book/list', name: 'app_books_list')] // Corrigé le nom de la route
          public function bookList(BookRepository $rep): Response
          {
             $books = $rep->findBy(['published' => true]);
             $booksu = $rep->findBy(['published' => false]);
             $publishedCount = count($books);
             $unpublishedCount = count($booksu);

             return $this->render('book/books.html.twig', [
             'books' => $books,
             'publishedCount' => $publishedCount,
             'unpublishedCount' => $unpublishedCount,
             ]);
         }
         #[Route('/book/edit/{id}', name: 'app_book_edit')]
          public function edit(Request $request, Book $book, EntityManagerInterface $em): Response
         {
         $form = $this->createForm(BookType::class, $book); // Créer le formulaire avec l'auteur existant

          $form->handleRequest($request); // Gérer la requête

          if ($form->isSubmitted() && $form->isValid()) {
          $em->flush(); // Enregistrer les modifications dans la base de données

             return $this->redirectToRoute('app_books_list'); // Rediriger après succès
          }

          return $this->render('book/edit.html.twig', [
          'form' => $form->createView(), // Passer le formulaire à la vue
          'book' => $book // Passer l'auteur pour l'affichage si nécessaire
           ]);
         }
         #[Route('/book/delete/{id}', name: 'app_book_delete')]
         public function delete(Book $book, EntityManagerInterface $em): Response
         {
             $em->remove($book); // Supprimer l'auteur
             $em->flush(); // Enregistrer les modifications dans la base de données
         
             return $this->redirectToRoute('app_books_list'); // Rediriger après succès
         }
         /*#[Route('/book/{id}', name: 'app_book_show')]
         public function show(Book $book): Response
         {
          return $this->render('book/show.html.twig', [
            'book' => $book,
            ]);
         
         }*/
         #[Route('/book/countbook', name: 'app_book_count')]
          public function countBook(EntityManagerInterface $entityManager): Response
          {
          $query = $entityManager->createQuery(
        "SELECT COUNT(b) FROM App\Entity\Book b WHERE b.category = :category"
         )->setParameter('category', 'Romance');

            $romanceCount = $query->getSingleScalarResult(); // Récupération du résultat unique

         return $this->render('book/count.html.twig', [
        'romanceCount' => $romanceCount, ]);
          }
          #[Route('/book/listp', name: 'app_book_listp')]
          public function listP(EntityManagerInterface $entityManager): Response
          {
            $startDate = new \DateTime('2014-01-01');
            $endDate = new \DateTime('2018-12-31');
            $query = $entityManager->createQuery("SELECT b FROM App\Entity\Book b WHERE b.pulicationDate BETWEEN :start AND :end")->setParameter('start', $startDate)
            ->setParameter('end', $endDate);

            $books = $query->getResult(); 

         return $this->render('book/booklist.html.twig', [
        'books' => $books, // On passe le nombre à la vue
    ]);
}

         

}
