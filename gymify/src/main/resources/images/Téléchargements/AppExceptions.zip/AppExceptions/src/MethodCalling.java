public class MethodCalling {

    public void method1() throws StackOverflowError {
        System.out.println("Method 1 is called.");
        this.method2();
    }

    private void method2() throws StackOverflowError {
        System.out.println("Method 2 is called.");

    }

    public static void main(String[] args) {
        MethodCalling mc = new MethodCalling();
        try {
            mc.method1();
        } catch (StackOverflowError e) {
            System.out.println("StackOverflowError.");
        }
    }
}

