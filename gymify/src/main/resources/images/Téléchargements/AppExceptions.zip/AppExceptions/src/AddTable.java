public class AddTable {

    public static void main(String[] args) {
        int[] array = new int[3];

        try {
            for (int i = 0; i < 4; i++) {
                array[i] = i;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Erreur : Tentative d'accès à un index en dehors des limites du tableau.");
        }
        System.out.println(array);

    }
}
