import java.io.IOException;

public class TestFinally {

    public static void main(String[] args) {
        try {
            System.out.println("Entrez un code : ");
            int x = System.in.read();
            System.out.println(x);
            System.out.println("Le code ASCII du caractère entré est : " + x);
        } catch (IOException e) {
            System.out.println("Erreur : Une IOException s'est produite lors de la lecture de l'entrée.");
            e.printStackTrace();
        } finally {
            System.out.println("Thank you, goodbye.");
        }
    }
}


