public class SuperHotel {
    static int[] tab;

    public void reserve() {
        tab[0] = 1;
    }

    public static void main(String[] args) {
        SuperHotel sp = new SuperHotel();
        try {
            sp.reserve();
        }catch(NullPointerException e){
            System.out.println(e.getMessage());
        }
    }
}
